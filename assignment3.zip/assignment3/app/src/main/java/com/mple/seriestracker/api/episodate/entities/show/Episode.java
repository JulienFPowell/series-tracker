package com.mple.seriestracker.api.episodate.entities.show;

public class Episode {
    public int season;
    public int episode;
    public String name;
    public String air_date;
}
