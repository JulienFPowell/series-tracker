package com.mple.seriestracker.api.episodate.entities.show;

import java.util.List;

public class TvShow {
    public TvShowResult tvShow;
}
