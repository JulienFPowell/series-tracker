package com.mple.seriestracker.api.episodate.entities.show;

public class Countdown {
    public int season;
    public int episode;
    public String name;
    public String air_date;
}
