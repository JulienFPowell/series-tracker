package com.mple.seriestracker;


public class ShowInfo {
    public long id;
    public String name;
    public String imagePath;
}
